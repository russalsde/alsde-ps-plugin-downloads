'use strict';
define(function(require) {
    var angular = require('angular');
    // Name of file, not the name of the module.
    require('components/shared/powerschoolModule');
    require('components/codesets/index');
    require('components/templatemanagement/index');
    require('components/healthdashboard/common/index');
    require('components/healthdashboard/healthplan/index');
    return angular.module('alsdeHealthPlanModule', ['powerSchoolModule', 'codesetsModule', 'templateModule', 'healthCommonModule', 'healthplanModule']);
});