'use strict';
define(function(require) {
    var module = require('components/alsde/health/module');
    var $j = require('jquery');
    var _ = require('underscore');
    module.controller('viewController', function($rootScope, $scope, $http, $httpParamSerializer, $window, i18nUtils, healthCommonService, healthPlanService) {
            
        $scope.healthPlan = {};
        $scope.healthplanAcknowledged = false;
        $scope.healthplanDocumentVersion = null;
        $scope.acknowlegeChecked = false;
        $scope.schoolId = '';
        $scope.currentTeacherId = '';
        $scope.termId = '';
        $scope.healthplanId = '';

        $scope.getHealthPlan = function(planId, iSchoolId, iTeacherId, iTermId) {
            $scope.schoolId = iSchoolId;
            $scope.currentTeacherId = iTeacherId;
            $scope.termId = iTermId;
            $scope.healthplanId = planId;
            let endpoint = '/teachers/alsde/health/studenthealthplan.json?planId=' + planId;
            $http.get(endpoint).then( function (response) {
                var healthPlan = response.data;
                healthPlan.pop();
                checkAcknowledgement(healthPlan[0]);
                $scope.healthplanDocumentVersion = healthPlan[0].documentVersion;
                $scope.healthPlan = healthPlan[0];
                loadHealthPlan();
            });
        };

        var checkAcknowledgement = function(item){
            
            var records = [];
            var qData = null;
            var versionmodtime = i18nUtils.parseJsonDate(item.versionmodtime,true);
            
            qData = {'studentdcid' : item.studentDcid, 'schoolid' : $scope.schoolId, 'curtermid' : $scope.termId, healthstudentplanid:item.healthplanId };

            var promise = $http.get('/teachers/alsde/health/healthplanreadreceipts.json?studentDcid=' + item.studentDcid + '&schoolId=' + $scope.schoolId + '&curTermId=' + $scope.termId).then(function(response) {
            //var promise = healthCommonService.getData('com.powerschool.core.documents.get_readreceipts_for_healthplans', qData, false).then(function(jsonData) {
                var healthplanReadReceipts = response.data;
                if (healthplanReadReceipts.length > 1) {
                    healthplanReadReceipts.pop();
                    item.healthplanAcknowledged = false;
                    for (var i = 0; i < healthplanReadReceipts.length; i++) {
                        var readdate = i18nUtils.parseJsonDate(healthplanReadReceipts[i].readdate,false);
                        var status = healthplanReadReceipts[i].status;
                        var documentversion = i18nUtils.parseJsonDate(healthplanReadReceipts[i].documentversion,true);
                        var versionmodtime_check = (healthplanReadReceipts[i].versionmodtime ? new Date(healthplanReadReceipts[i].versionmodtime): null);
                        var documentversion_check = (healthplanReadReceipts[i].documentversion ? new Date(healthplanReadReceipts[i].documentversion): null);
                        records.push({
                            readreceiptid: healthplanReadReceipts[i].readreceiptid == null ? 0 : healthplanReadReceipts[i].readreceiptid,
                            planname: healthplanReadReceipts[i].healthplanname,
                            dateread: (readdate ? new Date(readdate): null),
                            documentversion: documentversion != null ? i18nUtils.getLocalizedDate(documentversion) + ' ' + i18nUtils.makeStrFromTime(documentversion,true) : null,
                            name: healthplanReadReceipts[i].lastfirst,
                            status: status,
                            //isEnded: (status ? status == ctrlData.invertedStatusMap['Ended'] : false),
                            usertype: healthplanReadReceipts[i].usertype,
                            healthstudentplanid: healthplanReadReceipts[i].healthstudentplanid,
                            userid: healthplanReadReceipts[i].userid
                         });
                         if((healthplanReadReceipts[i].userid == $scope.currentTeacherId) && (healthplanReadReceipts[i].readreceiptid != null) && (documentversion_check.setMilliseconds(0) == versionmodtime_check.setMilliseconds(0))){
                            item.healthplanAcknowledged = true;
                            $scope.healthplanAcknowledged = true;
                         }
                    }
                }
            });
        };

        var loadHealthPlan = function(){
            //Appending html to iframe body
            if(($j('#plan_details_readOnly')) != undefined && $j('#plan_details_readOnly') != null)
            {
                var iframeDocument = $j('#plan_details_readOnly').find('#iframe_plan_details_readOnly')[0];

                //We need to keep this here for browsers other than firefox
                iframeDocument.contentDocument.body.innerHTML = $scope.healthPlan.healthplanData;

                //This is only used for firefox which does not add html in above line
                iframeDocument.addEventListener('load', function()
                {
                    iframeDocument.contentDocument.body.innerHTML = $scope.healthPlan.healthplanData;
                });
            }
        };

        $scope.acknowledgeHealthPlan = function(teacherLastFirst){
            var planAcknowledgement = {
                category: "HEALTHPLAN",
                documentId: parseInt($scope.healthplanId),
                documentVersion: $scope.healthplanDocumentVersion,
                userType: 'TEACHER',
                userId: parseInt($scope.currentTeacherId),
                lastFirst: teacherLastFirst,
                seedNow: true
            };

            healthPlanService.acknowledge(planAcknowledgement, function(response) {
                // success
                $window.location.href = "https://" + $window.location.host + "/teachers/alsde/health/studenthealthplans.html"
            }, function(error) {
                // error
                if (error.status === 409) {
                    setError(getTranslation('acknowledgement_already_exists'));
                } else {
                    setError(getTranslation('oops_something_went_wrong_please_contact_your_system_administrator'));
                }
            });
        };
    });
});