'use strict';
define(function(require) {
    require('components/alsde/health/controllers/healthPlanListController');
    require('components/alsde/health/controllers/healthPlanViewController');
});