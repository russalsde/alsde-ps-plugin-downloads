'use strict';
define(function(require) {
    require('components/shared/index');
    require('components/alsde/health/module');
    require('components/alsde/health/controllers/index');
    //require('components/healthdashboard/healthplan/services/index');
    require('components/healthdashboard/healthplan/index');
});