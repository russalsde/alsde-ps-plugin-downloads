define(['angular', 'components/shared/index'], function (angular) {

    var healthplanviewerApp = angular.module('healthplanviewerApp', ['powerSchoolModule']);

    healthplanviewerApp.controller('hpvController', function($rootScope, $scope, $http, $httpParamSerializer, i18nUtils, healthCommonService) {

        $scope.teacherStudentHealthPlans = [];

        var getTeacherStudentHealthPlans = function() {
            let endpoint = '/teachers/alsde/health/studenthealthplans.json';
            $http.get(endpoint).then( function (response) {
                var studentHealthPlans = response.data;
                studentHealthPlans.pop();
                //studentHealthPlans.forEach(getHealthPlanData);
                //studentHealthPlans.forEach(checkAcknowledgement);
                $scope.teacherStudentHealthPlans = studentHealthPlans;

            });
        };

        var checkAcknowledgement = function(teacherDcid){
            //code here
        };

        getTeacherStudentHealthPlans();
        

    });

    healthplanviewerApp.controller('viewHealthPlanController', function($rootScope, $scope, $http, $httpParamSerializer) {
        
        $scope.healthPlan = {};

        $scope.getHealthPlan = function(planId) {
            let endpoint = '/teachers/alsde/health/studenthealthplan.json?planId=' + planId;
            $http.get(endpoint).then( function (response) {
                var healthPlan = response.data;
                healthPlan.pop();
                $scope.healthPlan = healthPlan[0];
                loadHealthPlan();

            });
        };

        var loadHealthPlan = function(){
            //Appending html to iframe body
            if(($j('#plan_details_readOnly')) != undefined && $j('#plan_details_readOnly') != null)
            {
                var iframeDocument = $j('#plan_details_readOnly').find('#iframe_plan_details_readOnly')[0];

                //We need to keep this here for browsers other than firefox
                iframeDocument.contentDocument.body.innerHTML = $scope.healthPlan.healthplanData;

                //This is only used for firefox which does not add html in above line
                iframeDocument.addEventListener('load', function()
                {
                    iframeDocument.contentDocument.body.innerHTML = $scope.healthPlan.healthplanData;
                });
            }
        };

    });

});