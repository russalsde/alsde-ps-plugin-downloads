'use strict';
define(function(require) {
    var module = require('components/alsde/health/module');
    var $j = require('jquery');
    var _ = require('underscore');

    module.controller('listController', function($rootScope, $scope, $http, $httpParamSerializer, i18nUtils, healthCommonService) {

        $scope.teacherStudentHealthPlans = [];
        $scope.schoolId = '';
        $scope.currentTeacherId = '';
        $scope.termId = '';
        $scope.showReadReceipts = false;

        $scope.setIds = function(iSchoolId, iTeacherId, iTermId){
            $scope.schoolId = iSchoolId;
            $scope.currentTeacherId = iTeacherId;
            $scope.termId = iTermId;
        };

        var getTeacherStudentHealthPlans = function() {
            let endpoint = '/teachers/alsde/health/studenthealthplans.json';
            $http.get(endpoint).then( function (response) {
                var studentHealthPlans = response.data;
                studentHealthPlans.pop();
                studentHealthPlans.forEach(checkAcknowledgement);
                $scope.teacherStudentHealthPlans = studentHealthPlans;
            });
        };

        var checkAcknowledgement = function(item){ 
            var records = [];
            var readreceipts = [];
            var qData = null;
            var versionmodtime = i18nUtils.parseJsonDate(item.versionmodtime,true);

            item.documentversion_display = item.versionmodtime != "" ? i18nUtils.getLocalizedDate(versionmodtime) + ' ' + i18nUtils.makeStrFromTime(versionmodtime,true) : i18nUtils.getLocalizedDate(item.whencreated) + ' ' + i18nUtils.makeStrFromTime(item.whencreated,true);

            //console.log($scope.schoolId);
            qData = {'studentdcid' : item.studentDcid, 'schoolid' : $scope.schoolId, 'curtermid' : $scope.termId, healthstudentplanid:item.healthplanId };

            var promise = $http.get('/teachers/alsde/health/healthplanreadreceipts.json?studentDcid=' + item.studentDcid + '&schoolId=' + $scope.schoolId + '&curTermId=' + $scope.termId).then(function(response) {
            //var promise = healthCommonService.getData('com.powerschool.core.documents.get_readreceipts_for_healthplans', qData, false).then(function(jsonData) {
                var healthplanReadReceipts = response.data;
                if (healthplanReadReceipts.length > 1) {
                    healthplanReadReceipts.pop();
                    item.healthplanAcknowledged = false;
                    for (var i = 0; i < healthplanReadReceipts.length; i++) {
                        var readdate = healthplanReadReceipts[i].readdate != "" ? i18nUtils.parseJsonDate(healthplanReadReceipts[i].readdate,false) : "";
                        var status = healthplanReadReceipts[i].status;
                        var documentversion = healthplanReadReceipts[i].documentversion != "" ? i18nUtils.parseJsonDate(healthplanReadReceipts[i].documentversion,true) : "";
                        var versionmodtime_check = (healthplanReadReceipts[i].versionmodtime ? new Date(healthplanReadReceipts[i].versionmodtime): "");
                        var documentversion_check = (healthplanReadReceipts[i].documentversion ? new Date(healthplanReadReceipts[i].documentversion): "");
                        
                        records.push({
                            readreceiptid: healthplanReadReceipts[i].readreceiptid == "" ? 0 : healthplanReadReceipts[i].readreceiptid,
                            planname: healthplanReadReceipts[i].healthplanname,
                            dateread: (readdate ? new Date(readdate).toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: '2-digit',
                                day: '2-digit'
                                }): ""),
                            documentversion: documentversion != "" ? i18nUtils.getLocalizedDate(documentversion) + ' ' + i18nUtils.makeStrFromTime(documentversion,true) : "",
                            name: healthplanReadReceipts[i].lastfirst,
                            status: status,
                            //isEnded: (status ? status == ctrlData.invertedStatusMap['Ended'] : false),
                            usertype: healthplanReadReceipts[i].usertype,
                            healthstudentplanid: healthplanReadReceipts[i].healthstudentplanid,
                            userid: healthplanReadReceipts[i].userid
                         });
                         
                         if((healthplanReadReceipts[i].userid == $scope.currentTeacherId) && (healthplanReadReceipts[i].readreceiptid != "")){
                            readreceipts.push({
                                readreceiptid: healthplanReadReceipts[i].readreceiptid == "" ? 0 : healthplanReadReceipts[i].readreceiptid,
                                dateread: (readdate ? new Date(readdate).toLocaleDateString('en-US', {
                                    year: 'numeric',
                                    month: '2-digit',
                                    day: '2-digit'
                                    }): ""),
                                documentversion: documentversion != "" ? i18nUtils.getLocalizedDate(documentversion) + ' ' + i18nUtils.makeStrFromTime(documentversion,true) : "",
                                name: healthplanReadReceipts[i].lastfirst,
                                acknowledged: documentversion != ""
                            });
                            item.readreceipts = readreceipts;
                         }

                        // NOTE: test when documentversion check and versionmodtime check are null
                         if((healthplanReadReceipts[i].userid == $scope.currentTeacherId) && (healthplanReadReceipts[i].readreceiptid != "") && (documentversion_check.setMilliseconds(0) == versionmodtime_check.setMilliseconds(0))){
                            item.healthplanAcknowledged = true;
                         }

                         //console.log(item);
                         
                    }
                }
            }); // end of http promise to get read receipts
        };

        getTeacherStudentHealthPlans();

    });
});