'use strict';
define(function(require) {
    var module = require('components/alsde/fitnessscores/module');
    var _ = require('underscore');
    var psFormatterUtils = require('components/shared/utils/psFormatterUtils');

    module.factory('FitnessScoresGridWidgetService', ['$http', '$parse', function($http, $parse) {

        self.filter = function(advancedFilters, quickFilters, dataRows) {
            var filteredData = [];
            
            if (advancedFilters != null && advancedFilters.length > 0) {
            	_.each(advancedFilters, function(filter) {
            			filter.updateSearchValueRegex();
            	});
            }
            if (quickFilters != null && quickFilters.length > 0) {
            	_.each(quickFilters, function(filter) {
            			filter.updateSearchValueRegex();
            	});
            }
            
            _.each(dataRows,function(dataRow){
                
                var simpleFilterPassed = true;
                var advancedFiltersPassed = true;

                if (advancedFilters != null && advancedFilters.length > 0) {
                    //Only specific filters have been activated.
                    //find will get the first occurrence of a failure to pass
                    //If nothing fails to pass the filter, it will return 'undefined'
                    var fails = _.find(advancedFilters, function(gwFilterObj) {
                        return !gwFilterObj.passesFilter(dataRow, true);
                    });
                    advancedFiltersPassed = (fails == null);
                }
                
                if (quickFilters != null && quickFilters.length > 0) {
                    var passes = _.find(quickFilters, function(gwFilterObj) {
                        return gwFilterObj.passesFilter(dataRow, false);
                    });
                    simpleFilterPassed = (passes != null);
                }
              
                if (simpleFilterPassed && advancedFiltersPassed) {
                	filteredData[filteredData.length] = dataRow;
                }
            });
            return filteredData;
        };
        
        return {
            getFitnessScores: function(paginationHelper) {
                if (!paginationHelper) {
                    
                    let endpoint = '/teachers/alsde/fitnesstestscores/json/fitnesstestscores.json';
                    return $http.get(endpoint).then( function (response) {
                        if(response.data === '' || response.data == null){
                            const emptyFitnessScores = [
                                {
                                    StudentLastFirst: '',
                                    LastName: '',
                                    FirstName: '',
                                    StudentNumber: 0,
                                    StudentDcid: 0,
                                    TestDate: new Date(),
                                    StudentTestDcid: 0,
                                    TestScoreSortOrder: 0,
                                    AssessmentAreaCode: '',
                                    AssessmentArea: '',
                                    AssessmentType: '',
                                    AssessmentTypeDescription: '',
                                    AssessmentTypeObjective: '',
                                    NumericScore: '',
                                    TestUnits: '',
                                    AssessmentResultCode: '',
                                    AssessmentResult: '',
                                    TestUnitsDescription: '',
                                    SchoolCode: 0,
                                    SchoolName: '',
                                    GradeLevel: '',
                                    TermId: 0,
                                    CourseName: '',
                                    TeacherId: 0,
                                    TeacherLastFirst: ''
                                }
                            ];
                            return emptyFitnessScores;
                        }
                        else{
                            var fitnessscoresJson = JSON.parse(response.data);
                            const typedfitnessscoresJson = fitnessscoresJson.map(item => {
                                return {
                                    StudentLastFirst: String(item.StudentLastFirst),
                                    LastName: String(item.LastName),
                                    FirstName: String(item.FirstName),
                                    StudentNumber: Number(item.StudentNumber),
                                    StudentDcid: Number(item.StudentDcid),
                                    TestDate: new Date(item.TestDate),
                                    StudentTestDcid: Number(item.StudentTestDcid),
                                    TestScoreSortOrder: Number(item.TestScoreSortOrder),
                                    AssessmentAreaCode: String(item.AssessmentAreaCode),
                                    AssessmentArea: String(item.AssessmentArea),
                                    AssessmentType: String(item.AssessmentType),
                                    AssessmentTypeDescription: String(item.AssessmentTypeDescription),
                                    AssessmentTypeObjective: String(item.AssessmentTypeObjective),
                                    NumericScore: String(item.TestUnits) === 'MinSec' ? Number(Math.floor(Number(item.NumericScore)/1000/60)) : Number(item.NumericScore),
                                    TestUnits: String(item.TestUnits) === 'MinSec' ? ':' + String(Number(((item.NumericScore)/1000)%60)) + ' min:sec' : ' ' + String(item.TestUnits),
                                    AssessmentResultCode: String(item.AssessmentResultCode),
                                    AssessmentResult: String(item.AssessmentResult),
                                    TestUnitsDescription: String(item.TestUnitsDescription),
                                    SchoolCode: Number(item.SchoolCode),
                                    SchoolName: String(item.SchoolName),
                                    GradeLevel: String(item.GradeLevel),
                                    TermId: Number(item.TermId),
                                    CourseName: String(item.CourseName),
                                    Section: String(item.Section),
                                    TeacherId: Number(item.TeacherId),
                                    TeacherLastFirst: String(item.TeacherLastFirst)
                                };
                            });
                            return typedfitnessscoresJson;
                        }
                    });
        
                }
                else {
                    //This is the refresh function.
                    console.log('\n\n');

                    console.log(' - - - - - Pagination Information - - - - -');
                    console.log('Page number: ' + paginationHelper.getPageNumber());
                    console.log('Rows par page): ' + paginationHelper.getRowsPerPage());

                    console.log('\n');
                    console.log(' - - - - - Sort Information - - - - - ');
                    console.log('Sort Direction: ' + paginationHelper.getSortDirection());
                    console.log('Sort Columns (' + paginationHelper.getSortColumns().length + '): ' + paginationHelper.getSortColumns().join());

                    console.log('\n');
                    console.log(' - - - - - Filter Information - - - - -');
                    console.log('Advanced: ' + JSON.stringify(paginationHelper.getFilterData()));
                    console.log('Simple: ' + JSON.stringify(paginationHelper.getSimpleFilterData()));

                    console.log('\n\n');

                    //Do REST call
                    //filtered results go into this variable
                    var filteredList = self.filter(paginationHelper.gridWidgetFilters, paginationHelper.gridWidgetSimpleFilters, fitnessscores);

                    paginationHelper.numberOfRows = filteredList.length;
                    var maxPageNumber = Math.ceil(paginationHelper.numberOfRows / paginationHelper.rowsPerPage);
                    if (this.pageNumber > maxPageNumber) {
                        this.pageNumber = maxPageNumber;
                    }

                    //Now sort what's left
                    if (paginationHelper.getSortColumns().length > 0) {
                        var sortColumn = paginationHelper.getSortColumns()[0];
                        var lookup = $parse(sortColumn);
                        filteredList.sort(function(a, b) {
                            var answer;
                            if (lookup(a) > lookup(b)) {
                                answer = 1;
                            }
                            else if (lookup(a) < lookup(b)) {
                                answer = -1;
                            }
                            else {
                                answer = 0;
                            }

                            return paginationHelper.getSortDirection() === 'desc' ? -1 * answer : answer;
                        });
                    }

                    var pageOfData = [];
                    if (filteredList.length > 0) {
                        for (var i = (paginationHelper.getPageNumber() - 1) * paginationHelper.getRowsPerPage();
                             i < paginationHelper.getPageNumber() * paginationHelper.getRowsPerPage() && i < filteredList.length; i++) {
                            pageOfData.push(filteredList[i]);
                        }
                    }

                    //After rest call
                    paginationHelper.setNumberOfRows(filteredList.length);
                    console.log('Setting Number Of Rows (Update this every time): ' + paginationHelper.numberOfRows);
                    paginationHelper.filteredNumberOfRows = pageOfData.length;
                    return pageOfData;
                }
            }
        };
    }]);
});