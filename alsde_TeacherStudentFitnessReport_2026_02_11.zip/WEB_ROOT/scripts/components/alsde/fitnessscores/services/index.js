define(function(require){
    'use strict';
    require('components/alsde/fitnessscores/services/FitnessScoresGridWidgetService');
});