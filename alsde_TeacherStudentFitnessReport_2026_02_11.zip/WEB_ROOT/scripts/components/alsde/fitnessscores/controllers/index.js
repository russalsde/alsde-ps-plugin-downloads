'use strict';
define(function(require){
    require('components/alsde/fitnessscores/controllers/FitnessScoresGridWidgetController');
});