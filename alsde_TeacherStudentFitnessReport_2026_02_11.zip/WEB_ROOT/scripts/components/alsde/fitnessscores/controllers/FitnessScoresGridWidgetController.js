'use strict';
define(function(require) {
    var module = require('components/alsde/fitnessscores/module');
    
    var SchoolNameMap = {};

    module.run(function($window) {
        SchoolNameMap = $window.schoolJson;
        delete SchoolNameMap.finalkey;
    });

    var _ = require('underscore');

    var PaginationHelper = require('components/widgets/models/PaginationHelper');

    var AssessmentAreaMap = {
        'Aerobic Cardiovascular Endurance': 'Aerobic Cardiovascular Endurance',
        'Flexibility': 'Flexibility',
        'Muscular Strength/Endurance': 'Muscular Strength/Endurance',
        'Abdominal Strength/Endurance': 'Abdominal Strength/Endurance'
    };

    var AssessmentTypeMap = {
        '': ''
    };

    var AssessmentResultMap = {
        'Healthy': 'Healthy',
        'High Fitness': 'High Fitness',
        'Needs Improvement': 'Needs Improvement'
    };

    var inverseAssessmentAreaMap = _.invert(AssessmentAreaMap);
    var inverseAssessmentTypeMap = _.invert(AssessmentTypeMap);
    var inverseAssessmentResultMap = _.invert(AssessmentResultMap);
    var inverseSchoolNameMap = _.invert(SchoolNameMap);

    module.controller('FitnessScoresGridWidgetController', [
        '$scope',
        'FitnessScoresGridWidgetService',
        'i18nService',
        '$filter',
        '$q', function($scope,
                            fitnessScoresGridWidget,
                            i18nService,
                            $filter,
                            $q) {
        
        var cData = {
                AssessmentAreaMap: AssessmentAreaMap,
                AssessmentTypeMap: AssessmentTypeMap,
                AssessmentResultMap: AssessmentResultMap,
                SchoolNameMap: SchoolNameMap,
                pageOfFitnessScores: [],
                fitnessReportSelection: "1",
                columnDescriptions: [
                    {
                        title: 'psx.html.admin_ui_example.gridwidgetexamples.lastname',
                        key: 'lastName',
                        fieldKey: 'LastName',
                        show: true
                    },
                    {
                        title: 'psx.html.admin_ui_example.gridwidgetexamples.firstname',
                        key: 'firstName',
                        fieldKey: 'FirstName',
                        show: true
                    },
                    {
                        title: 'psx.html.admin_ui_example.gridwidgetexamples.linesofcode',
                        key: 'studentNumber',
                        fieldKey: 'StudentNumber|number',
                        show: false
                    },
                    {
                        title: 'psx.html.admin_ui_example.gridwidgetexamples.birthday',
                        key: 'testDate',
                        fieldKey: 'TestDate|date',
                        show: false
                    },
                    {
                        title: 'psx.html.admin_ui_example.gridwidgetexamples.favoritecolor',
                        key: 'assessmentarea',
                        fieldKey: 'AssessmentArea|select',
                        filterInfo: AssessmentAreaMap,
                        filterName: 'AssessmentArea',
                        show: false
                    },
                    {
                        title: 'psx.html.admin_ui_example.gridwidgetexamples.favoritecolor',
                        key: 'assessmenttype',
                        fieldKey: 'AssessmentType|select',
                        filterInfo: AssessmentTypeMap,
                        filterName: 'AssessmentType',
                        show: false
                    },
                    {
                        title: 'psx.html.admin_ui_example.gridwidgetexamples.numberofcars',
                        key: 'assessmentScore',
                        fieldKey: 'NumericScore|number',
                        show: false
                    }
                ],
                haltGridWidget: function() {
                    // Some validation check would go here to prevent user to go to next page if invalid data is present
                    return Math.random() > 0.5;
                }
            };

            var scoresPromise = fitnessScoresGridWidget.getFitnessScores().then(function (serviceData){
                cData.fitnessScores = serviceData;
                cData.pgController = new PaginationHelper(function() {
                    cData.pageOfFitnessScores = fitnessScoresGridWidget.getFitnessScores(cData.pgController);
                });
            });
            
            $q.all([scoresPromise]).then(function(results) {
                //
            });

            $scope.gwFitnessScoresCtrlData = cData;

            i18nService.getPrefixes('psx.admin.admin_ui_examples').then(function() {
                _.each(cData.columnDescriptions, function(descriptionObj) {
                    descriptionObj.title = $filter('translate')(descriptionObj.title);
                });
            });

    }
    ]).filter('showNiceMonths', function() {
        return function(input) {
            if (input > 12) {
                var num = input / 12.0;
                return num.toFixed(1) + ' Years';
            }

            return input + ' Months';
        };
    }).filter('AssessmentArea', function() {
        return function(input) {
            return inverseAssessmentAreaMap[input];
        };
    }).filter('AssessmentType', function() {
        return function(input) {
            return inverseAssessmentTypeMap[input];
        };
    }).filter('AssessmentResult', function() {
        return function(input) {
            return inverseAssessmentResultMap[input];
        };
    }).filter('SchoolName', function() {
        return function(input) {
            return inverseSchoolNameMap[input];
        };
    });

});