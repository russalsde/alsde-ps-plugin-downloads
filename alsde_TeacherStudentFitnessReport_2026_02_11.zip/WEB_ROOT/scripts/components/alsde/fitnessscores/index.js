'use strict';
define(function(require) {
    require('components/alsde/fitnessscores/controllers/index');
    require('components/alsde/fitnessscores/services/index');
});