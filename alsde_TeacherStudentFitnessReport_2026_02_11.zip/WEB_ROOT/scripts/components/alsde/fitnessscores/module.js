'use strict';
define(function(require) {
    // Name of file, not the name of the module.
    require('components/shared/powerschoolModule');
    require('components/widgets/module');
	require('lib/angucomplete/angucomplete-alt-3.0.0/angucomplete-alt');

    var angular = require('angular');

    return angular.module('alsdefitnessscoresModule', ['powerSchoolModule', 'widgets',  'angucomplete-alt']);
});