define(['angular', 'components/shared/index'], function (angular) {

    var staffContactsApp = angular.module('staffContactsApp', ['powerSchoolModule','ngSanitize']);

    function ViewController($http) {

        // Use 'this' to bind properties and methods
        var vm = this; // Assign 'this' to 'vm' (ViewModel) for consistency

        vm.newcontact = {
            id: -1,
            firstName: ""
        };

        vm.contacts = [];
        vm.hasprimary = false;

        vm.getContacts = function() {
            let endpoint = 'json/emergencycontacts.json';
            $http.get(endpoint).then(function(response) {

                if(response.data!='') {
                    var contacts=angular.fromJson(response.data);
                    vm.contacts=contacts;
                }
                else {
                    vm.contacts=[];
                }
                console.log(vm.contacts);
                vm.contacts.some(contact => {
                    if (contact.isprimary == true) {
                        vm.hasprimary = true;
                        return true; // Breaks out of the loop
                    }
                });
            });
        };

        vm.editContact = function(contact) {
            let status = contact.editing;
            vm.contacts.forEach(function(obj) {
                obj.editing = 0;
            });
            contact.editing = status ? 0 : 1;
        };

        vm.getContacts();

    };

    ViewController.$inject = ['$http'];

    staffContactsApp.controller('ViewController', ViewController);

    staffContactsApp.controller('drawerController', function($scope) {

        var init = function() {
            
            $scope.$emit('open.drawer.event', function(callback, properties) {
                $scope.staffcontact = properties.data;
                callback();
            });
            
            $scope.$emit('cancel.drawer.event', function(callback, properties) {
                callback();
            });
            
            $scope.$emit('save.drawer.event', function(callback, properties) {
                callback($scope.submitEditContactForm($scope.staffcontact.id));
            });
       };
       
       init();

       $scope.submitEditContactForm = function(contactid) {
            var formElement = document.getElementById('editContactForm' + contactid);
            var lastnameElement = document.getElementById('ec_lastname' + contactid);
            if (formElement.checkValidity() && lastnameElement.value) {
                formElement.submit();
                return true;
            }
            else{
                return false;
            }
       };

    });   

});